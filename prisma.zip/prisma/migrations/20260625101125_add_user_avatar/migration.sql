-- AlterTable
ALTER TABLE `users` ADD COLUMN `avatar_url` LONGTEXT NULL;
